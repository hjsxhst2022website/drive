#include <winsock2.h>
#include <ws2tcpip.h>
#include <filesystem>
#include <bits/stdc++.h>
using namespace std;
namespace fs = filesystem;  // ȷ�����д���
vector<string> getFilesInDirectory(const string& path);
string FixUTF8(const string &input);
int binarySearch(const vector<string>& arr,const string& target);
// ��ȡ�ļ��ֽ����ĺ���
int getFileSize(const string& filename) {
	ifstream file(filename, ios::binary | ios::ate);
	if (!file.is_open()) {
		return -1;
	}
	int size = static_cast<int>(file.tellg());
	file.close();
	
	return size;
}

string DecodeUrl(const string &encoded) {
	string decoded;
	for (size_t i = 0; i < encoded.size(); ++i) {
		if (encoded[i] == '%' && i + 2 < encoded.size()) {
			char hex1 = encoded[i + 1];
			char hex2 = encoded[i + 2];
			if (isxdigit(hex1) && isxdigit(hex2)) {
				string hex = encoded.substr(i + 1, 2);
				decoded += static_cast<char>(stoi(hex, nullptr, 16));
				i += 2;
			} else {
				decoded += encoded[i];
			}
		} else if (encoded[i] == '+') {
			decoded += ' ';
		} else {
			decoded += encoded[i];
		}
	}
	return decoded;
}
bool isSend304(string filepath) {
	vector<string> path={"/payment.jpg","/footer.jpg","/favicon.ico","/index.html","/others.html"};
	for(int i=0;i<path.size();i++){
		if(filepath==path[i])
			return 1;
	}
	return 0;
}
int normalfind(vector<string> a,string b);
#define shift(x, n) (((x) << (n)) | ((x) >> (32-(n))))//���Ƶ�ʱ�򣬸�λһ��Ҫ���㣬�����ǲ������λ
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))    
#define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define I(x, y, z) ((y) ^ ((x) | (~z)))
#define A 0x67452301
#define B 0xefcdab89
#define C 0x98badcfe
#define D 0x10325476
//strBaye�ĳ���
unsigned int strlength;
//A,B,C,D����ʱ����
unsigned int atemp;
unsigned int btemp;
unsigned int ctemp;
unsigned int dtemp;
//����ti unsigned int(abs(sin(i+1))*(2pow32))
const unsigned int k[]={
	0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,
	0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,0x698098d8,
	0x8b44f7af,0xffff5bb1,0x895cd7be,0x6b901122,0xfd987193,
	0xa679438e,0x49b40821,0xf61e2562,0xc040b340,0x265e5a51,
	0xe9b6c7aa,0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,
	0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,0xa9e3e905,
	0xfcefa3f8,0x676f02d9,0x8d2a4c8a,0xfffa3942,0x8771f681,
	0x6d9d6122,0xfde5380c,0xa4beea44,0x4bdecfa9,0xf6bb4b60,
	0xbebfbc70,0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,
	0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,0xf4292244,
	0x432aff97,0xab9423a7,0xfc93a039,0x655b59c3,0x8f0ccc92,
	0xffeff47d,0x85845dd1,0x6fa87e4f,0xfe2ce6e0,0xa3014314,
	0x4e0811a1,0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391};
//����λ����
const unsigned int s[]={7,12,17,22,7,12,17,22,7,12,17,22,7,
	12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,
	4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,
	15,21,6,10,15,21,6,10,15,21,6,10,15,21};
const char str16[]="0123456789abcdef";
void mainLoop(unsigned int M[])
{
	unsigned int f,g;
	unsigned int a=atemp;
	unsigned int b=btemp;
	unsigned int c=ctemp;
	unsigned int d=dtemp;
	for (unsigned int i = 0; i < 64; i++)
	{
		if(i<16){
			f=F(b,c,d);
			g=i;
		}else if (i<32)
		{
			f=G(b,c,d);
			g=(5*i+1)%16;
		}else if(i<48){
			f=H(b,c,d);
			g=(3*i+5)%16;
		}else{
			f=I(b,c,d);
			g=(7*i)%16;
		}
		unsigned int tmp=d;
		d=c;
		c=b;
		b=b+shift((a+f+k[i]+M[g]),s[i]);
		a=tmp;
	}
	atemp=a+atemp;
	btemp=b+btemp;
	ctemp=c+ctemp;
	dtemp=d+dtemp;
}
/*
*��亯��
*������Ӧ����bits��448(mod512),�ֽھ���bytes��56��mode64)
*��䷽ʽΪ�ȼ�һ��1,����λ����
*������64λ��ԭ������
*/
unsigned int* add(string str)
{
	unsigned int num=((str.length()+8)/64)+1;//��512λ,64���ֽ�Ϊһ��
	unsigned int *strByte=new unsigned int[num*16];    //64/4=16,������16������
	strlength=num*16;
	for (unsigned int i = 0; i < num*16; i++)
		strByte[i]=0;
	for (unsigned int i=0; i <str.length(); i++)
	{
		strByte[i>>2]|=(str[i])<<((i%4)*8);//һ�������洢�ĸ��ֽڣ�i>>2��ʾi/4 һ��unsigned int��Ӧ4���ֽڣ�����4���ַ���Ϣ
	}
	strByte[str.length()>>2]|=0x80<<(((str.length()%4))*8);//β������1 һ��unsigned int����4���ַ���Ϣ,������128����
	/*
	*����ԭ���ȣ�����ָλ�ĳ��ȣ�����Ҫ��8��Ȼ����С�������Է��ڵ����ڶ���,���ﳤ��ֻ����32λ
	*/
	strByte[num*16-2]=str.length()*8;
	return strByte;
}
string changeHex(int a)
{
	int b;
	string str1;
	string str="";
	for(int i=0;i<4;i++)
	{
		str1="";
		b=((a>>i*8)%(1<<8))&0xff;   //������ÿ���ֽ�
		for (int j = 0; j < 2; j++)
		{
			str1.insert(0,1,str16[b%16]);
			b=b/16;
		}
		str+=str1;
	}
	return str;
}
string getMD5(string source)//MD5�����㷨
{
	atemp=A;    //��ʼ��
	btemp=B;
	ctemp=C;
	dtemp=D;
	unsigned int *strByte=add(source);
	for(unsigned int i=0;i<strlength/16;i++)
	{
		unsigned int num[16];
		for(unsigned int j=0;j<16;j++)
			num[j]=strByte[i*16+j];
		mainLoop(num);
	}
	return changeHex(atemp).append(changeHex(btemp)).append(changeHex(ctemp)).append(changeHex(dtemp));
}

class IPRequestLimiter {
private:
	unordered_map<string, deque<chrono::time_point<chrono::steady_clock>>> ipRequestsMap;
	int maxRequestsPerSecond;
	int maxRequestsPerIP;
public:
	IPRequestLimiter(int maxRequestsPerSecond, int maxRequestsPerIP) : maxRequestsPerSecond(maxRequestsPerSecond), maxRequestsPerIP(maxRequestsPerIP) {}
	
	bool allowRequest(const string& ipAddress) {
		// Remove expired requests from the queue for the IP address
		auto& requestQueue = ipRequestsMap[ipAddress];
		while (!requestQueue.empty() && chrono::steady_clock::now() - requestQueue.front() >= chrono::seconds(1)) {
			requestQueue.pop_front();
		}
		
		// Check if the number of requests within one second exceeds the limit for the IP address
		if (requestQueue.size() < maxRequestsPerIP && ipRequestsMap.size() < maxRequestsPerSecond) {
			// Add current request time to the queue for the IP address
			requestQueue.push_back(chrono::steady_clock::now());
			return true;
		} else {
			return false;
		}
	}
};
int maxRequestsPerSecond = 100;
int maxRequestsPerIP = 50;
IPRequestLimiter limiter(maxRequestsPerSecond, maxRequestsPerIP);
string filekinds(string filepath) {
	vector<string> back={".png",".jpg",".jpeg",".ico",".js",".css",".mp3",".txt"};
	for(size_t i=0;i<back.size();i++){
		size_t a=filepath.find(back[i]);
		if(a!=string::npos)
			return back[i];
	}
	return "null";
}
vector<string> usernames;
vector<string> passwords;
vector<string> cid;
vector<string> superusers;
void printError(const char* msg) {
	cerr << msg << ": " << WSAGetLastError() << endl;
}
void send304(SOCKET clientSocket){
	string header="HTTP/1.1 304 Not Modified\r\nDate: "+to_string(time(0))+"\r\n\r\n";
	send(clientSocket, header.c_str(), header.length(),0);
}
void sendthing(string fullContent,SOCKET clientSocket){
	string header = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: " + to_string(fullContent.length()) + "\r\n\r\n";
	send(clientSocket, header.c_str(), header.length(), 0);
	send(clientSocket, fullContent.c_str(), fullContent.length(), 0);
}
void sendpng(string fullContent, SOCKET clientSocket) {
	string header = "HTTP/1.1 200 OK\r\nCache-Control: max-age=3600\r\nContent-Type: image/png\r\nContent-Length: " + to_string(fullContent.size()) + "\r\n\r\n";
	send(clientSocket, header.c_str(), header.length(), 0);
	send(clientSocket, fullContent.c_str(), fullContent.size(), 0);
}
void sendmp3(string fullContent, SOCKET clientSocket) {
	string header = "HTTP/1.1 200 OK\r\nCache-Control: max-age=3600\r\nContent-Type: audio/mpeg\r\nContent-Length: " + to_string(fullContent.size()) + "\r\n\r\n";
	send(clientSocket, header.c_str(), header.length(), 0);
	send(clientSocket, fullContent.c_str(), fullContent.size(), 0);
}
void sendtxt(string fullContent, SOCKET clientSocket) {
	string header = "HTTP/1.1 200 OK\r\nContent-Type: text/html;\r\nContent-Length: " + to_string(fullContent.size()) + "\r\n\r\n";
	send(clientSocket, header.c_str(), header.length(), 0);
	send(clientSocket, fullContent.c_str(), fullContent.size(), 0);
}
void sendjs(string fullContent, SOCKET clientSocket) {
	string header = "HTTP/1.1 200 OK\r\nCache-Control: max-age=3600\r\nContent-Type: text/javascript\r\nContent-Length: " + to_string(fullContent.size()) + "\r\n\r\n";
	send(clientSocket, header.c_str(), header.length(), 0);
	send(clientSocket, fullContent.c_str(), fullContent.size(), 0);
}
void sendcss(string fullContent, SOCKET clientSocket) {
	string header = "HTTP/1.1 200 OK\r\nCache-Control: max-age=3600\r\nContent-Type: text/css\r\nContent-Length: " + to_string(fullContent.size()) + "\r\n\r\n";
	send(clientSocket, header.c_str(), header.length(), 0);
	send(clientSocket, fullContent.c_str(), fullContent.size(), 0);
}
void sendicon(string fullContent, SOCKET clientSocket) {
	string header = "HTTP/1.1 200 OK\r\nCache-Control: max-age=3600\r\nContent-Type: image/x-icon\r\nContent-Length: " + to_string(fullContent.size()) + "\r\n\r\n";
	send(clientSocket, header.c_str(), header.length(), 0);
	send(clientSocket, fullContent.c_str(), fullContent.size(), 0);
}
void sendjpg(string fullContent, SOCKET clientSocket) {
	string header = "HTTP/1.1 200 OK\r\nCache-Control: max-age=3600\r\nContent-Type: image/jpeg\r\nContent-Length: " + to_string(fullContent.size()) + "\r\n\r\n";
	send(clientSocket, header.c_str(), header.length(), 0);
	send(clientSocket, fullContent.c_str(), fullContent.size(), 0);
}

// ����HTTP�����в���������·��
string parseHttpRequest(const string& request) {
	size_t methodEnd = request.find(' ');
	if (methodEnd != string::npos) {
		size_t pathStart = methodEnd + 1;
		size_t pathEnd = request.find(' ', pathStart);
		if (pathEnd != string::npos) {
			return request.substr(pathStart, pathEnd - pathStart);
		}
	}
	return "/";
}
string randstring(int leng) {
	const string alphanum = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	string random_string = "";
	unsigned int seed = chrono::system_clock::now().time_since_epoch().count();
	mt19937 generator(seed);
	
	for (int i = 0; i < leng; ++i) {
		random_string += alphanum[generator() % alphanum.length()];
	}
	return random_string;
}
string times(time_t timestamp) {
	tm* tm_info = localtime(&timestamp);
	char buffer[80];
	strftime(buffer, 80, "%Y-%m-%d %H:%M:%S", tm_info);
	return buffer;
}
void sendHtml(SOCKET clifd, string filePath,string workingcid,bool checked=0) {
	if(checked==0){
		int allowed=filePath.find("/../");
		if(allowed!=string::npos){
			sendHtml(clifd,"htmlfiles/error/403.html",workingcid);
		}
		string kind=filekinds(filePath);
		if(kind!="null"){
			fstream file;
			file.open(filePath,ios::in|ios::binary);
			if(!file.is_open()) {
				cout << "�ļ��޷��򿪣� " << filePath << endl;
				sendHtml(clifd,"htmlfiles/error/404.html",workingcid,0);
				return;
			}
			string buffer;
			while(!file.eof()){
				string a;
				getline(file,a);
				buffer+=a+"\n";
			}
			string fileContent = buffer;
			if(fileContent.empty()) {
				cout << "�ļ�Ϊ�գ� " << filePath << endl;
				file.close();
				return;
			}
			if(kind==".png")
				sendpng(fileContent, clifd);
			if(kind==".jpg"||kind==".jpeg")
				sendjpg(fileContent,clifd);
			if(kind==".ico")
				sendicon(fileContent,clifd);
			if(kind==".js")
				sendjs(fileContent,clifd);
			if(kind==".css")
				sendcss(fileContent,clifd);
			if(kind==".mp3")
				sendmp3(fileContent,clifd);
			if(kind==".txt")
				sendtxt(fileContent,clifd);
			file.close();
			file.clear();
			return;
		}
		size_t a=filePath.find("users");
		if(a!=string::npos){
			if(workingcid=="no cid"){
				sendHtml(clifd,"htmlfiles/error/403.html",workingcid,1);
			}
//			a=filePath.find("users/"+workingcid+"/liuyan.html");
//			if(a==string::npos){
//				sendHtml(clifd,"htmlfiles/error/403.html",workingcid,1);
//				return;
//			}else{
			fstream r1;
			r1.open("cid.txt",ios::out);
			int b=normalfind(cid,workingcid);
			if(b!=-1){
				sendHtml(clifd,"htmlfiles/m/users/"+usernames[b]+"/liuyan.html",usernames[b],1);
			}
	//		}
		}
	}
// ���ȷ���head.html������
		ifstream headFile("htmlfiles/head.html", ios::in | ios::binary);
		string headContent;
		if (headFile.is_open()) {
			ostringstream ss;
			ss << headFile.rdbuf();
			headContent = ss.str();
			headFile.close();
		} else {
			// ����޷��ҵ�head.html������ѡ����һ��������Ϣ���ߺ���
			headContent = ""; // ���head.html�����ڣ��������κ�����
		}
		// Ȼ����Ŀ���ļ�������
		ifstream targetFile(filePath, ios::in | ios::binary);
		string targetContent;
		if (!targetFile.is_open()) {
			// ���Ŀ���ļ���ʧ�ܣ����Է���404����ҳ��
			if (strcmp(&filePath[0], "htmlfiles/error/404.html") != 0) { // �������޵ݹ�
				sendHtml(clifd, "htmlfiles/error/404.html",workingcid);
			} else {
				// �����404ҳ�涼�����ڣ�����һ���򵥵�404��Ϣ
				const char* msg = "HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\n\r\n<html><body><h1>404 Not Found</h1></body></html>";
				send(clifd, msg, strlen(msg), 0);
			}
			return;
		}
		
		ostringstream ss;
		ss << targetFile.rdbuf();
		targetContent = ss.str();
		targetFile.close();
		
		// �ϲ�head.html��Ŀ���ļ�������
		string fullContent = headContent + targetContent;
		
		// ����HTTP��Ӧͷ����ȷ���ͻ���֪���������ͺ����ݳ���
		string head="HTTP/1.1 200 OK\r\n";
		if(filePath=="htmlfiles/error/404.html"){
			head="HTTP/1.1 404 Not Found\r\n";
		}else if(filePath=="htmlfiles/error/403.html"){
			head="HTTP/1.1 403 Forbidden\r\n";
		}
//	if(isSend304(filePath)==1)
		head+="Cache-Control: max-age=3600\r\n";//"Date: "+to_string(time(0))+"\r\n";
		string header = head+"Content-Type: text/html\r\nContent-Length: " + to_string(fullContent.length()) + "\r\n\r\n";
		send(clifd, header.c_str(), header.length(), 0);
		
		// ���ͺϲ��������
		send(clifd, fullContent.c_str(), fullContent.length(), 0);
}
string cleanstring(const string& input) {
	const vector<string>& substringsToFilter={"%3Cembed","%3Cscript%3E","%3C%2Fscript%3E","%3Cobject%3E","%3Cembed%3E","onerror","onload","onclick","javascript","onmouseover","onmouseout","onkeydown","width","height"};
	string filteredString = input;
	for (const string& substring : substringsToFilter) {
		size_t pos = filteredString.find(substring);
		while (pos != string::npos) {
			// �ÿ��ַ����滻��ƥ�䵽���Ӵ�
			filteredString.replace(pos, substring.length(), "");
			// ����������һ��ƥ��λ��
			pos = filteredString.find(substring, pos);
		}
	}
	return filteredString;
}
string replaceGreaterThan(const string& input) {
	string result;
	for (char ch : input) {
		if (ch == '<') {
			result += "&gt;";
		} else {
			result += ch;
		}
	}
	return result;
}
string wrapLinesWithParagraphs(const string &input);
void makemessagehtml(){
	while(1){
		for(int i=0;i<usernames.size();i++){
			fstream html;
			html.open("htmlfiles/message/"+usernames[i]+".txt");
			string thing;
			if(!html.is_open()){
				html.close();
				html.clear();
				continue;
			}
			while(!html.eof()){
				string l;
				getline(html,l);
				thing+=l+'\n';
			}
			html.close();
			html.clear();
			html.open("htmlfiles/message/"+usernames[i]+".html",ios::out);
			html<<R"(<div style="word-wrap: break-word;max-width:800px;white-space: pre-wrap;background-color: #F5F5DC;opacity: 0.9;padding: 10px;border-radius: 10px;
			overflow-y: scroll; /* �� auto */max-height:450px;">)"<<wrapLinesWithParagraphs(thing)<<"</div>";
			html.close();
			html.clear();
		}
		Sleep(1000);
	}
}
void maketimehtml(){
	while(1){
		for(int i=0;i<usernames.size();i++){
			fstream html;
			html.open("htmlfiles/time/"+usernames[i]+"time_capsule.html",ios::out);
			html<<R"(
			<head>
			<style>
			hr {
			border: 0; /* �Ƴ�Ĭ�ϱ߿� */
			border-top: 2px dashed #333333; /* �������� */
			width: 80%;
			margin: 10px auto;
			}
			.container {
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			flex-direction: column; /* ���ִ��ϵ������� */
			position: absolute;
			font-size: 100%;
			font-weight: normal;
			font-style: normal;
			color: #F5F5DC;
			display: flex;
			margin: 0 auto;
			overflow: auto;  /* ���������ڵ����ݹ��� */
			background-color: #F5F5DC; /* ����͸����ɫ */
			padding: 20px;
			border-radius: 10px;
			box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
			max-width: 800px;
			max-height:500px;
			text-align: center;
			opacity: 0.9; /* ��ʼ���� */
			transition: opacity 0.5s ease-in-out; /* ƽ������Ч�� */
		}.jianjiea {
			
			word-break: break-all;  /* ǿ�Ƴ�����������ط��Ͽ� */
			display: block;         /* ʹ���ӱ�Ϊ�鼶Ԫ�أ����㻻�� */
			font-size:16px;
			color: #2F4F4F;
		}
		.jianjiea:hover{
			font-size:16px;
			color: #696969;
		}
		
			</style>
			</head>
			<html>
			<body>
			<div class="container" id="things">
			)";
			vector<string> all=getFilesInDirectory("htmlfiles/users/"+usernames[i]+"/time");
			for(int j=0;j<all.size();j++){
				if(all[j].length()!=16+usernames[i].length()+30)
					continue;
				fstream r1;
				r1.open(all[j]);
				string p;
				while(!r1.eof()){
					string l;
					getline(r1,l);
					p+=l+'\n';
				}
				fstream html2;
				html2.open("htmlfiles/time/"+all[j].substr(22+usernames[i].length(),20)+".html",ios::out);
				html2<<R"(
				<style>
				.container {
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
				flex-direction: column; /* ���ִ��ϵ������� */
				position: absolute;
				font-size: 100%;
				font-weight: normal;
				font-style: normal;
				color: #808080;
				display: flex;
				margin: 0 auto;
				overflow: auto;  /* ���������ڵ����ݹ��� */
				background-color: #F5F5DC; /* ����͸���׻�ɫ */
				opacity: 0.9; /* ���ð�͸��Ч�� */
				padding: 20px;
				font-size:16px;
				border-radius: 10px;
				box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
				max-width: 800px;
				max-height:500px;
				text-align: center;
			}
			</style>
<html><body><div class="container" id="letter">
				)"<<wrapLinesWithParagraphs(DecodeUrl(p))<<endl<<R"(
					</div>
</body>
<script>
					var utcTimestamp = Date.now();
					var localTimestamp = utcTimestamp + (new Date().getTimezoneOffset() * 60 * 1000);
					var opentime=)";
fstream r;
r.open("htmlfiles/users/"+usernames[i]+"/time/"+all[j].substr(22+usernames[i].length(),20)+"opentime.txt");
int opentime;
r>>opentime;
r.close();
r.clear();
html2<<opentime<<R"(;
function timestampToDateFormat(timestamp) {
const dateObj = new Date(timestamp); // ����Date����
const year = dateObj.getFullYear(); // ��ȡ���
const month = ("0" + (dateObj.getMonth() + 1)).slice(-2); // ��ȡ�·ݣ�������
const day = ("0" + dateObj.getDate()).slice(-2); // ��ȡ���ڣ�������

return `${year}-${month}-${day}`; // ����ת��������ڸ�ʽ
}
if(localTimestamp/1000<opentime){
	document.getElementById('letter').innerHTML='<p>������ʱ�仹û������Ҫ�ż�Ŷ~</p><p>����ʱ�䣺'+timestampToDateFormat(opentime*1000)+'</p>';
}

</script>
					)";
				html2.close();
				html2.clear();
				p=DecodeUrl(p).substr(0,300);
				if(p.length()==300)
					p+="...";
				p=wrapLinesWithParagraphs(FixUTF8(p));
				html<<"<a class=\"jianjiea\"href=\""<<all[j].substr(22+usernames[i].length(),20)+".html\">"<<p<<"</a><hr>";
				r1.close();
				r1.clear();
			}
			html<<R"(</div>
</body>
<script>
document.getElementById('things').classList.add('show');
</script>
</html>)";
			html.close();
			html.clear();
		}
		Sleep(1000);
	}
}
void timetime(string a,string cid_,SOCKET clifd,bool ismobile){
	string delimiter = "%20WheNToOPenTImE%20";
	size_t pos = a.find(delimiter);  // ���� 'HTTP/1.1' ���ַ����е�λ��
	string say;
	if (pos != string::npos) {
		// ��ȡ��ͷ�� 'HTTP/1.1' ֮ǰ�Ĳ���
		say = a.substr(14, pos-14);
	}
	say=replaceGreaterThan(say);
	fstream saysave;
	say=cleanstring(say);
	if(cid_=="no cid"){
		return;
	}else{
		string usernamess=usernames[normalfind(cid,cid_)];
		string name=randstring(20);
		string filepath="htmlfiles/users/"+usernamess+"/time/"+name+".txt";
		saysave.open(&filepath[0],ios::out);
		saysave<<times(time(0))<<endl<<say<<endl;
		saysave.close();
		saysave.clear();
		
		filepath="htmlfiles/users/"+usernamess+"/time/"+name+"opentime.txt";
		saysave.open(&filepath[0],ios::out);
		string delimiter = "HTTP/1.1";
		size_t pos = a.find(delimiter);  // ���� 'HTTP/1.1' ���ַ����е�λ��
		string opentime;
		if (pos != string::npos) {
			// ��ȡ��ͷ�� 'HTTP/1.1' ֮ǰ�Ĳ���
			opentime = a.substr(34+say.length(), 10);
		}
		saysave<<opentime<<endl;
		saysave.close();
		saysave.clear();
		
		filepath="htmlfiles/users/"+usernamess+"/time/"+name+".txt";
		saysave.open(&filepath[0],ios::out);
		if(ismobile==0)
			saysave<<times(time(0))<<endl<<say<<endl;
		else
			saysave<<times(time(0))<<endl<<say.substr(2,say.length())<<endl;
		saysave.close();
		saysave.clear();
	}
	sendthing("ok",clifd);
}

void sendsay(string a,string cid_,SOCKET clifd,bool ismobile){
	string delimiter = "HTTP/1.1";
	size_t pos = a.find(delimiter);  // ���� 'HTTP/1.1' ���ַ����е�λ��
	string say;
	if (pos != string::npos) {
		// ��ȡ��ͷ�� 'HTTP/1.1' ֮ǰ�Ĳ���
		say = a.substr(13, pos-13);
	}
	say=replaceGreaterThan(say);
	fstream saysave;
	say=cleanstring(say);
	if(cid_=="no cid"){
		return;
	}else{
		string usernamess=usernames[normalfind(cid,cid_)];
		string filepath="htmlfiles/users/"+usernamess+"/sendsay.txt";
		saysave.open(&filepath[0],ios::app);
		saysave<<times(time(0))<<endl<<say<<endl;
		saysave.close();
		saysave.clear();
		
		filepath="htmlfiles/m/users/"+usernamess+"/sendsay.txt";
		saysave.open(&filepath[0],ios::app);
		if(ismobile==0)
		saysave<<times(time(0))<<endl<<say<<endl;
		else
			saysave<<times(time(0))<<endl<<say.substr(2,say.length())<<endl;
		saysave.close();
		saysave.clear();
	}
	sendthing("ok",clifd);
}
string wrapLinesWithParagraphs(const string &input) {
	stringstream ss(input);
	string line;
	string result;
	
	while (getline(ss, line)) {
		result += "<p>" + line + "</p>\n"; // ÿһ�м���<p>��</p>
	}
	
	return result;
}
struct FileEntry {
	string path;
	time_t modified_time; // �ļ�����޸�ʱ��
};

// ��ȡָ��Ŀ¼�µ������ļ��������޸�ʱ�䵹������
vector<string> getFilesInDirectory(const string& path) {
	vector<FileEntry> files;
	
	// ȷ��·����һ����ЧĿ¼
	if (fs::exists(path) && fs::is_directory(path)) {
		for (const auto& entry : fs::directory_iterator(path)) {
			if (fs::is_regular_file(entry.status())) {
				// ��ȡ�ļ��� last_write_time
				auto ftime = fs::last_write_time(entry);
				
				// �� file_time_type ת��Ϊ system_clock::time_point
				auto sys_time = chrono::time_point_cast<chrono::system_clock::duration>(ftime - fs::file_time_type::clock::now() + chrono::system_clock::now());
				
				// �� system_clock::time_point ת��Ϊ time_t
				time_t modifiedTime = chrono::system_clock::to_time_t(sys_time);
				
				// �����ļ��б�
				files.push_back({entry.path().string(), modifiedTime});
			}
		}
		
		// ���޸�ʱ�併�����������ļ���ǰ��
		sort(files.begin(), files.end(), [](const FileEntry& a, const FileEntry& b) {
			return a.modified_time > b.modified_time; // ʱ�䵹��
		});
		
		// ֻ�����ļ�·��
		vector<string> sortedFiles;
		for (const auto& file : files) {
			sortedFiles.push_back(file.path);
		}
		return sortedFiles;
	} else {
		cerr << "Invalid directory path." << endl;
		return {};
	}
}

bool isValidUTF8(const string &str) {
	int bytesToProcess = 0;
	
	for (size_t i = 0; i < str.size(); i++) {
		unsigned char ch = str[i];
		
		if (bytesToProcess == 0) {
			if ((ch & 0x80) == 0) {
				// ASCII: 0xxxxxxx (1-byte character)
				continue;
			} else if ((ch & 0xE0) == 0xC0) {
				// 2-byte character: 110xxxxx
				bytesToProcess = 1;
			} else if ((ch & 0xF0) == 0xE0) {
				// 3-byte character: 1110xxxx
				bytesToProcess = 2;
			} else if ((ch & 0xF8) == 0xF0) {
				// 4-byte character: 11110xxx
				bytesToProcess = 3;
			} else {
				return false; // Invalid UTF-8
			}
		} else {
			// Expect continuation byte: 10xxxxxx
			if ((ch & 0xC0) != 0x80) {
				return false;
			}
			bytesToProcess--;
		}
	}
	
	return bytesToProcess == 0; // All characters completed properly
}

// �޸� UTF-8 �ַ�����ɾ��ĩβ����
string FixUTF8(const string &input) {
	string fixed = input;
	
	while (!fixed.empty() && !isValidUTF8(fixed)) {
		fixed.pop_back(); // ɾ�����һ���ֽ�
	}
	
	return fixed;
}
void shudong(){
	while(1){
		fstream r1;
		r1.open("htmlfiles\\venting_space.html",ios::out);
	r1<<R"(<!DOCTYPE html>
	<html lang="zh">
	<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>���� - ��������</title>
	<link rel="stylesheet" href="/venting_space_css.css">
	</head>
	<body>
	<div class="container" style="z-index:999999999">
	<div id="messagesContainer" class="messages-container">
	<h2>�������˵ķ��� or �Լ�����ɧ</h2>
	<div id="messagesList">)";
		vector<string> files;
		files=getFilesInDirectory("htmlFiles/anonymous");
		for(int i=0;i<files.size();i++){
			string p;
			if(files[i].length()!=44||files[i].find(".html")!=string::npos)
				continue;
			fstream r2;
			r2.open(files[i]);
			string q;
			while(!r2.eof()){
				getline(r2,q);
				p+=q+"\n";
			}
			r2.close();
			r2.clear();
			r2.open(files[i].substr(0,files[i].length()-4)+".html",ios::out);
			r2<<R"(<!DOCTYPE html>
			<html lang="zh">
			<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title>�������˵ķ���</title>
			<style>
			.speak {
			max-width: 70vw; /* ������ */
			max-height: 80vh;
			font-size: 16px; /* �����С */
			}
			@media (min-width: 768px) {
			.speak {
				max-width: 600px; /* ������ */
				max-height: 500px;
				font-size: 16px; /* �����С */
			}
		}
		@media (min-width: 1024px) {
			.speak  {
				max-width: 800px; /* ������ */
				max-height: 500px;
				font-size: 18px; /* �����С */
			}
		}

			/* ��ʽ���� */
			.speak {
			margin: 0 auto;
			overflow: auto;      /* ���ݳ���ʱ��ʾ������ */
			word-wrap: break-word; /* ǿ�Ƶ��ʻ��� */
			font-family: 'Arial', sans-serif; /* �������� */
			color: #333; /* ������ɫ */
			background-color: #f4f4f4; /* ������ɫ */
			padding: 20px; /* �ڱ߾� */
			border-radius: 8px; /* Բ�Ǳ߿� */
			box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* ��ӰЧ�� */
			margin: 20px auto; /* ������ʾ */
			text-align: center; /* �����ı� */
			position: relative; /* ����Ԫ�ؿ���ʹ�þ��Զ�λ */
		}
	p {
		line-height: 1.5;  /* �����м�� */
	}
	/* �����ͼ�� */
	.view-count {
		display: flex;
		align-items: center;
		justify-content: flex-end; /* �����ݿ��� */
		position: fixed;
		bottom: 70px;  /* �¶��� */
		right: 70px;   /* �Ҷ��� */
		font-size: 16px;
		color: #555;
	}
	.eye-icon {
		width: 24px;
		height: 24px;
		margin-right: 5px;
	}
	</style>
	</head>
	<body>
	
	<div class="speak" id="speak">)"<<wrapLinesWithParagraphs(DecodeUrl(p))<<R"(</div>
		<!-- ����� -->
		<div class="view-count">
		<svg class="eye-icon" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#696969" stroke-width="4">
		<path d="M2 32s10-18 30-18 30 18 30 18-10 18-30 18S2 32 2 32z"/>
		<circle cx="32" cy="32" r="8" fill="black"/>
		</svg>
		<span>
		)";
fstream r3;
r3.open(files[i].substr(0,40)+"shows.txt");
unsigned int m;
r3>>m;
r3.close();
r3.clear();
r2<<m+1<<R"(</span>  <!-- ��������� -->
		</div>
		<script>
document.addEventListener('DOMContentLoaded', function () {
const markdownit = window.markdownit(); // ���� markdown-it �Ѿ���ȷ����
const markdownText = document.getElementById('speak').innerText;
const htmlContent = markdownit.render(markdownText);
document.getElementById('speak').innerHTML = htmlContent; // ����ҳ������    
});
</script>
		</body>
		</html>)";
			r2.close();
			r2.clear();
			string jianjie=DecodeUrl(p);
			if(jianjie.length()>1000){
				jianjie=jianjie.substr(0,1000);
				jianjie=FixUTF8(jianjie);
				jianjie+="...";
			}
			r1<<"<a href=\""+files[i].substr(10,files[i].length()-14)+".html\" class=\"messagea\">"<<jianjie<<"<hr>";
		}
	r1<<R"(</div>
	</div>
	</div>
<script>
const markdownit = window.markdownit(); // ���� markdown-it �Ѿ���ȷ����

// ѡ������ class Ϊ "jianjie" ��Ԫ��
const jianjieElements = document.querySelectorAll('.messagea');

// ����ÿ��Ԫ�أ���ȡ���е��ı����ݣ���Ⱦ������Ԫ��
jianjieElements.forEach((element) => {
	const markdownText = element.innerText;  // ��ȡԪ�ص�ԭʼ�ı�����
	const htmlContent = markdownit.render(markdownText);  // ��Ⱦ�� HTML
	
	// ���¸�Ԫ�ص�����
	element.innerHTML = htmlContent;
});



</script>
	</body>
	</html>)";
		r1.close();
		r1.clear();
		Sleep(500);
	}
}
void sendsayanonymous(string a,string cid_,SOCKET clifd,bool ismobile){
	string delimiter = "HTTP/1.1";
	size_t pos = a.find(delimiter);  // ���� 'HTTP/1.1' ���ַ����е�λ��
	string say;
	if (pos != string::npos) {
		// ��ȡ��ͷ�� 'HTTP/1.1' ֮ǰ�Ĳ���
		say = a.substr(22, pos-22);
	}
	say=replaceGreaterThan(say);
	fstream saysave;
	say=cleanstring(say);
	if(cid_=="no cid"){
		return;
	}else{
		string usernamess=usernames[normalfind(cid,cid_)];
		string name=randstring(20);
		string filepath="htmlfiles/anonymous/"+name+".txt";
		saysave.open(&filepath[0],ios::out);
		saysave<<times(time(0))<<endl<<say<<endl;
		saysave.close();
		saysave.clear();
		saysave.open("htmlfiles/anonymous/"+name+"shows.txt",ios::out);
		saysave<<0;
		saysave.close();
		saysave.clear();
	}
	sendthing("ok",clifd);
}
int binarySearch(const vector<string>& arr,const string& target){
	int left=0;
	int right=arr.size()-1;
	while(left<=right) {
		int mid=left+(right-left)/2;
		if(arr[mid]==target){
			return mid;//�ҵ�Ŀ�꣬���ش���
		}else if(arr[mid]<target){
			left = mid+1;
		}else{
			right = mid-1;
		}
	}
	return -1;//Ŀ�겻����
}
void bug(string a){
	string register_=a.substr(14,a.length()-24);
}
void removeContentFromFile(const string& filename, const string& contentToDelete) {
	string line;
	ifstream inputFile(filename);
	string x=randstring(5);
	ofstream outputFile(x);
	if (!inputFile) {
		cerr << "Unable to open file " << filename << endl;
		return;
	}
	size_t pos = 0; // ������ҵ���λ��
	while (getline(inputFile, line)) {
		while ((pos = line.find(contentToDelete)) != string::npos) {
			// ɾ���ҵ�������
			line.erase(pos, contentToDelete.length());
		}
		// д�봦������е���ʱ�ļ�
		outputFile << line << endl;
	}
	inputFile.close();
	outputFile.close();
	remove(filename.c_str());
	rename(&x[0], filename.c_str());
	
	cout << "Content removed successfully." << endl;
}

string getspace(const string& input, const string& substring) {
	size_t startPos = input.find(substring);
	if (startPos != string::npos){
		string ret="";
		for(int i=startPos;i<input.size();i++){
			if(input[i]!='%'&&input[i]!=' '){
				ret+=input[i];
			}else if(input.substr(i,3)=="%20"||input[i]==' '){
				return ret.substr(substring.size(),ret.size()-substring.size());
			}else{
				ret+=input[i];
			}
		}
	} else// ���δ�ҵ��Ӵ�
		return ""; // ���ؿ��ַ�����ʾδ�ҵ�
}
bool checkPasswordComplexity(const string& password) {
	// ʹ���������ʽ����������Ƿ����Ҫ��
	regex regex("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$");
	return regex_match(password, regex);
}
vector<string> useremail;
void loadUsers();
void _register(string a,SOCKET clientSocket){
	string register_name=getspace(a,"/REGISTER");
	string register_word=getspace(a,"PASSWORD");
	string register_email=getspace(a,"address");
	if(!checkPasswordComplexity(register_word)){
		sendthing("password is too short.",clientSocket);
		return;
	}
	int x=binarySearch(usernames,register_name);
	if(x!=-1){
		sendthing("the token is registered.",clientSocket);
	}else{
		if(normalfind(useremail,register_email)!=-1){
			sendthing("the email is registered.",clientSocket);
			return;
		}else{
			fstream token;
			token.open("users.txt",ios::app);
			register_name=DecodeUrl(register_name);
			token<<register_name<<' '<<getMD5(register_word)<<endl;
			token.close();
			token.clear();
			system(&(string("md ")+"\"htmlfiles/users/"+register_name+"\"")[0]);
			fstream r1;
			r1.open(&("htmlfiles/users/"+register_name+"/liuyan.html")[0],ios::out);
			r1.close();
			r1.clear();
			r1.open(&("htmlfiles/users/"+register_name+"/sendsay.txt")[0],ios::out);
			r1.close();
			r1.clear();
			r1.open(&("htmlfiles/users/"+register_name+"/logindays.txt")[0],ios::out);
			r1.close();
			r1.clear();
			
			r1.open(&("htmlfiles/message/"+register_name+"/.txt")[0],ios::out);
			r1<<"����ʲôҲû��";
			r1.close();
			r1.clear();
			r1.open(&("htmlfiles/users/"+register_name+"/avatar.txt")[0],ios::out);
			r1<<"/favicon.ico";
			r1.close();
			r1.clear();
			r1.open("htmlfiles/users/"+register_name+"/background.txt",ios::out);
			r1<<"/back.png";
			r1.close();
			r1.clear();
			token.open("htmlfiles/m/users.txt",ios::app);
			register_name=DecodeUrl(register_name);
			token<<register_name<<' '<<getMD5(register_word)<<endl;
			token.close();
			token.clear();
			system(&(string("md ")+"\"htmlfiles/m/users/"+register_name+"\"")[0]);
			
			system(&(string("md ")+"\"htmlfiles/users/"+register_name+"/time")[0]);
			
			r1.open(&("htmlfiles/users/"+register_name+"/time/00000000000000000000.html")[0],ios::out);
			r1<<"��д��һ���򵥣�˽�ܵ��ռ�ƽ̨�����������˽��������ʱ��¼������˼����from 2025 to now";
			r1.close();
			r1.clear();
			r1.open(&("htmlfiles/m/users/"+register_name+"/liuyan.html")[0],ios::out);
			r1.close();
			r1.clear();
			
			r1.open(&("htmlfiles/m/users/"+register_name+"/sendsay.txt")[0],ios::out);
			r1.close();
			r1.clear();
			
			r1.open(&("htmlfiles/users/"+register_name+"/registertime.txt")[0],ios::out);
			r1<<time(0);
			r1.close();
			r1.clear();
			r1.open(&("htmlfiles/users/"+register_name+"/email.txt")[0],ios::out);
			r1<<register_email;
			r1.close();
			r1.clear();
			sendthing("OK register.",clientSocket);
			loadUsers();
		}
	}
}
struct about_user{
	string username;
	string password;
};
bool cmp(about_user a,about_user b){
	return a.username<b.username;
}
void loadsuperUsers(){
	fstream users;
	users.open("superusers.txt");
	if(users.is_open()){
		cout<<"superusers�ļ��򿪳ɹ�\n";
		while(!users.eof()){
			string name;
			users>>name;
			superusers.push_back(name);
		}
		users.close();
		users.clear();
	}else{
		cout<<"superusers�ļ���ʧ��\n";
		users.close();
		users.clear();
		exit(0);
	}
	sort(superusers.begin(),superusers.end());
	cout<<"users�ļ����سɹ�\n";
	cout<<endl;
	return;
}
void loademail(){
	vector<string> cache;
	for(int i=0;i<usernames.size();i++){
		fstream r1;
		r1.open("htmlfiles/users/"+usernames[i]+"/email.txt");
		string address;
		r1>>address;
		r1.close();
		r1.clear();
		cache.push_back(address);
		cout<<address<<endl;
	}
	useremail.clear();
	useremail=cache;
}
void loadUsers(){
	vector<about_user> cache;
	fstream users;
	users.open("users.txt");
	if(users.is_open()){
		cout<<"users�ļ��򿪳ɹ�\n";
		while(!users.eof()){
			string name,word;
			users>>name>>word;
			about_user cache_;
			cache_.password=word;
			cache_.username=name;
			cache.push_back(cache_);
		}
		users.close();
		users.clear();
	}else{
		cout<<"users�ļ���ʧ��\n";
		users.close();
		users.clear();
		exit(0);
	}
	sort(cache.begin(),cache.end(),cmp);
	for(int i=0;i<cache.size();i++){
		usernames.push_back(cache[i].username);
		passwords.push_back(cache[i].password);
	}
	if(cid.size()<cache.size()){
		while(cid.size()<cache.size())
			cid.push_back("notloggedon");
	}
	cout<<"users�ļ����سɹ�\n";
	cout<<endl;
	return;
}
int normalfind(vector<string> a,string b){
	for(int i=0;i<a.size();i++){
		if(a[i]==b.substr(0,30))
			return i;
	}
	return -1;
}
void cleandailydata(){
	while(1){
		if(time(0)%86400==57600){
			for(int i=0;i<usernames.size();i++){
				fstream r1;
				r1.open("htmlfiles/users/"+usernames[i]+"/logined.txt");
				if(!r1.is_open()){
					r1.close();
					r1.clear();
					r1.open("htmlfiles/users/"+usernames[i]+"/logindays.txt",ios::out);
					r1<<0;
				}
				r1.close();
				r1.clear();
				system(&("del htmlfiles/users/"+usernames[i]+"/logined.txt /q")[0]);
			}
		}
		Sleep(1000);
	}
}
void savecid(){
	while(1){
		fstream r2;
		r2.open("cid.txt");
		for(int i=0;i<cid.size();i++){
			r2<<cid[i]<<endl;
		}
		r2.close();
		r2.clear();
		Sleep(1000);
	}
}
void login(string a,SOCKET clientSocket){
	loadUsers();
	loadsuperUsers();
	string token=getspace(a,"/LOGIN");
	int x=binarySearch(usernames,token);
	if(x!=-1){
		cout<<"test:"<<getspace(a,"PASSWORD")<<' '<<passwords[x]<<endl;
		string word=getspace(a,"PASSWORD");
		if(passwords[x]!=getMD5(word)){
			sendthing("searched no token.",clientSocket);
			return;
		}else{
			string cid_=randstring(30);
			cid[x]=cid_;
			sendthing("searched token.\r\n"+cid_,clientSocket);
			int id=normalfind(cid,cid_);
			fstream r1;
			r1.open("htmlfiles/users/"+usernames[id]+"/logined.txt");
			if(!r1.is_open()){
				r1.close();
				r1.clear();
				r1.open("htmlfiles/users/"+usernames[id]+"/logined.txt",ios::out);
				r1.close();
				r1.clear();
				r1.open("htmlfiles/users/"+usernames[id]+"/logindays.txt");
				int day;
				r1>>day;
				r1.close();
				r1.clear();
				day++;
				r1.open("htmlfiles/users/"+usernames[id]+"/logindays.txt",ios::out);
				r1<<day;
				r1.close();
				r1.clear();
			}
			r1.close();
			r1.clear();
		}
	}else{
		sendthing("searched no token.",clientSocket);
	}
	return;
}
string getCookieValue(const string& cookieHeader, const string& cookieName) {
	// ���������� Cookie ���ƣ������Ⱥ�
	string fullCookieName = cookieName + "=";
	
	// ���� "Cookie" ��λ��
	size_t cookiePos = cookieHeader.find("Cookie:");
	if (cookiePos == string::npos) {
		return ""; // û���ҵ� "Cookie"�����ؿ��ַ���
	}
	
	// �� "Cookie" ��������ָ�����Ƶ� Cookie �ֶ�
	size_t pos = cookieHeader.find(fullCookieName, cookiePos);
	if (pos == string::npos) {
		return ""; // û���ҵ�ָ�����Ƶ� Cookie�����ؿ��ַ���
	}
	
	// ȷ�� Cookie ֵ�Ŀ�ʼλ��
	pos += fullCookieName.size();
	
	// ���ҷֺŻ��з���ȷ�� Cookie ֵ�Ľ���λ��
	size_t endPos = cookieHeader.find(';', pos);
	if (endPos == string::npos) {
		endPos = cookieHeader.size();
	}
	
	// ���ĩβ�л��з�����ȥ�����з�
	if (cookieHeader[endPos - 1] == '\n') {
		endPos--;
	}
	
	// ��ȡ Cookie ֵ
	string value = cookieHeader.substr(pos, endPos - pos);
	
	return value;
}

bool request_cache(const string& request) {//����Ƿ��л���
	string ifModifiedSinceHeader;
	size_t ifModifiedSincePos = request.find("If-Modified-Since:");
	
	if (ifModifiedSincePos != string::npos)
		return 1;
	return 0;
}
string randomstring(int type){
	srand(time(0));
	string m="";
	for(int i=1;i<=type;i++){
		m+=rand()%26+'a';
	}
	return m;
}
void SaveFileFromRequest(const string& requestBody, const string& boundary) {
	size_t partStartPos = 0, partEndPos = 0;
	
	while ((partStartPos = requestBody.find(boundary, partEndPos)) != string::npos) {
		partStartPos += boundary.length();
		partEndPos = requestBody.find(boundary, partStartPos);
		if (partEndPos == string::npos) partEndPos = requestBody.length();
		
		string filePart = requestBody.substr(partStartPos, partEndPos - partStartPos);
		
		// ���� "filename="
		size_t filenamePos = filePart.find("filename=\"");
		if (filenamePos == string::npos) continue;
		
		filenamePos += 10;
		size_t filenameEndPos = filePart.find("\"", filenamePos);
		string filename = filePart.substr(filenamePos, filenameEndPos - filenamePos);
		
		// �ҵ� `\r\n\r\n` ֮���ʵ���ļ�����
		size_t fileDataPos = filePart.find("\r\n\r\n");
		if (fileDataPos == string::npos) continue;
		fileDataPos += 4; // ���� "\r\n\r\n"
		
		string fileData = filePart.substr(fileDataPos);
		
		// ȥ���ļ�����ĩβ�� `\r\n--`
		size_t fileEndPos = fileData.find("\r\n--");
		if (fileEndPos != string::npos) fileData = fileData.substr(0, fileEndPos);
		
		// **�����ļ�**
		string filename_=randomstring(20);
		ofstream outFile(&("htmlfiles/users/"+filename+"/"+filename_+".mp3")[0], ios::binary);
		if (outFile.is_open()) {
			outFile.write(fileData.c_str(), fileData.size());
			outFile.close();
			cout << "File saved: " << filename << " (��С: " << fileData.size() << " �ֽ�)" << endl;
		} else {
			cerr << "Failed to save the file!" << endl;
		}// **�����ļ�**
		outFile.close();
		outFile.open(&("htmlfiles/m/users/"+filename+"/"+filename_+".mp3")[0], ios::binary);
		if (outFile.is_open()) {
			outFile.write(fileData.c_str(), fileData.size());
			outFile.close();
			cout << "File saved: " << filename << " (��С: " << fileData.size() << " �ֽ�)" << endl;
		} else {
			cerr << "Failed to save the file!" << endl;
		}
		outFile.close();
		fstream r1;
		r1.open(&("htmlfiles/m/users/"+filename+"/sendsay.txt")[0],ios::app);
		r1<<times(time(0))<<endl<<"[������Ƶ](/m/users/"<<filename<<"/"<<filename_<<".mp3)"<<endl;
	}
}

// ���� POST ������ȡ�������ļ�
void HandlePostRequest(vector<char> cache) {
	string requestData(cache.begin(), cache.end()-2);
	
	// ���� Content-Type
	size_t contentTypePos = requestData.find("Content-Type: multipart/form-data;");
	if (contentTypePos == string::npos) {
		cerr << "Content-Type not multipart/form-data!" << endl;
		return;
	}
	
	// ��ȡ boundary
	size_t boundaryPos = requestData.find("boundary=", contentTypePos);
	if (boundaryPos == string::npos) {
		cerr << "Boundary not found!" << endl;
		return;
	}
	
	string boundary = "--" + requestData.substr(boundaryPos + 9);  // "boundary=" ������9
	boundary = boundary.substr(0, boundary.find("\r\n"));
	
	// ��ȡ������
	size_t bodyStartPos = requestData.find("\r\n\r\n", contentTypePos) + 4;
	if (bodyStartPos == string::npos) {
		cerr << "Invalid HTTP request format!" << endl;
		return;
	}
	
	string requestBody = requestData.substr(bodyStartPos);
	
	// �����ļ�
	SaveFileFromRequest(requestBody, boundary);
}
bool isChineseCharacter(char ch) {
	// �ж��Ƿ�Ϊ�����ַ�
	// �����ַ�ͨ���� Unicode ��Χ�ǣ�\u4e00 - \u9fff
	// ��������ļ���UTF-8����
	return (ch & 0x80) != 0;  // �жϸ�λ�Ƿ�Ϊ1���򻯼��Ϊ��ASCII�ַ�
}

int countChineseCharacters(const string& filename) {
	fstream file(filename);  // �Զ�����ģʽ��
	if (!file.is_open()) {
		cerr << "�޷����ļ�!" << endl;
		return -1;
	}
	
	int charCount = 0;
	char ch;
	string l;
	while(!file.eof()){
		string m;
		getline(file,m);
		l+=m;
	}
	file.close();
	file.clear();
	l=DecodeUrl(l);
	for(int i=0;i<l.length();i++){
		// ����ַ��Ƿ�Ϊ����
		if (isChineseCharacter(l[i])) {
			++charCount;
		}
	}
	return charCount;
}
void email(string cache,SOCKET clinetSocket){
	string delimiter = "HTTP/1.1";
	size_t pos = cache.find(delimiter);  // ���� 'HTTP/1.1' ���ַ����е�λ��
	string address;
	if (pos != string::npos) {
		// ��ȡ��ͷ�� 'HTTP/1.1' ֮ǰ�Ĳ���
		address = cache.substr(24, pos-24);
	}
	string CAPTCHA;
	CAPTCHA=cache.substr(11,6);
	bool m=0;
	for(int i=0;i<useremail.size();i++){
		if(useremail[i].find(address)!=string::npos){
			m=1;
			break;
		}
	}
	if(m){
		sendthing("the email is registered.",clinetSocket);
		return;
	}else{
		fstream r1;
		r1.open("D:/email.txt",ios::out);
		r1<<"��ӭ������д��ע����֤�룺"+CAPTCHA+"���벻Ҫ�ر�ԭҳ�棬�رպ���֤��ʧЧ�������û��ע����д������Դ��ʼ��������������������ʱ�����������ʼ���ַ��<hr><a href=\"https://www.qingxie.ink\">��д</a> �� ����д�£��򵥼�¼��";
		r1.close();
		r1.clear();
		r1.open("D:/b.txt",ios::out);
		r1<<address;
		r1.close();
		r1.clear();
		system("node /nodemailer-demo/app.js");
		sendthing("ok",clinetSocket);
	}
}

//mutex logs;
void choosebackground(string name,string cid_){
	string delimiter = "HTTP/1.1";
	size_t pos = name.find(delimiter);  // ���� 'HTTP/1.1' ���ַ����е�λ��
	string url;
	if (pos != string::npos) {
		// ��ȡ��ͷ�� 'HTTP/1.1' ֮ǰ�Ĳ���
		url = name.substr(22, pos-22);
	}
	fstream r1;
	r1.open("htmlfiles/users/"+usernames[normalfind(cid,cid_)]+"/background.txt",ios::out);
	r1<<url;
	r1.close();
	r1.clear();
}
void chooseavatar(string name,string cid_){
	string delimiter = "HTTP/1.1";
	size_t pos = name.find(delimiter);  // ���� 'HTTP/1.1' ���ַ����е�λ��
	string url;
	if (pos != string::npos) {
		// ��ȡ��ͷ�� 'HTTP/1.1' ֮ǰ�Ĳ���
		url = name.substr(18, pos-18);
	}
	fstream r1;
	r1.open("htmlfiles/users/"+usernames[normalfind(cid,cid_)]+"/avatar.txt",ios::out);
	r1<<url;
	r1.close();
	r1.clear();
}
void handleClient(SOCKET clientSocket) {
	vector<char> buffer(1000000); 
	 // ���ʵĳ�ʼ��С
	int iResult = recv(clientSocket, buffer.data(), buffer.size(), 0);
	if (iResult == buffer.size()) {
		buffer.resize(buffer.size() * 30);  // ��������С����
		iResult = recv(clientSocket, buffer.data() + iResult, buffer.size() - iResult, 0);
	}
	if (iResult == SOCKET_ERROR) {
		cerr << "recv failed with error: " << WSAGetLastError() << endl;
		closesocket(clientSocket);
		WSACleanup();
		return;
	}
	if (iResult > 0) {
		SYSTEMTIME st;//���屾��ʱ��������ñ���Ϊ�ṹ��
		GetLocalTime(&st);//��ȡ����ʱ�亯��������Ϊʱ�����ָ��
		string request(buffer.begin(), buffer.end());
		cout<<"time:"<<st.wYear<<"��"<<st.wMonth<<"��"<<st.wDay<<"��"<<st.wHour<<"ʱ"<<st.wMinute<<"��"<<st.wSecond<<"��"<<endl;
		cout<<"recvBuf:";
		cout<<request<<endl;
		// ��������·��
		// ��ȡ�Զ˵�ַ��Ϣ
		sockaddr_in clientAddr;
		int clientAddrLen = sizeof(clientAddr);
		if (getpeername(clientSocket, (SOCKADDR*)&clientAddr, &clientAddrLen) == SOCKET_ERROR) {
			cerr << "getpeername failed: " << WSAGetLastError() << endl;
		}
		string workingcid;
		// �ӵ�ַ��Ϣ����ȡ IP ��ַ
		char clientIp[INET_ADDRSTRLEN];
		inet_ntop(AF_INET, &(clientAddr.sin_addr), clientIp, INET_ADDRSTRLEN);
		cout << "���ӵ�ip: " << clientIp << endl;
		string ip(clientIp);
//		if (limiter.allowRequest(ip)) {
//			cout << "ip " << ip << "ͨ����֤��" << endl;
//		} else {
//			cout << "ip " << ip << "����DOS����" << endl;
//			sendHtml(clientSocket,"htmlfiles/error/403.html",workingcid);
//		}
		
		string recvBuf(request);
		workingcid=getCookieValue(recvBuf,"cid");
		if(workingcid=="")
			workingcid="no cid";
		else if(normalfind(cid,workingcid)==0){
			workingcid="no cid";
		}else if(recvBuf.find("cid")==string::npos){
			workingcid="no cid";
		}
		cout<<"����cid:"<<workingcid<<endl;
		string cache_=recvBuf;
		
		string path = DecodeUrl(parseHttpRequest(request));
		if(path.find("..")!=string::npos){
			sendHtml(clientSocket,"htmlfiles/error/403.html",workingcid);
			closesocket(clientSocket);
			return;
		}
		if(path.find("/anonymous/")!=string::npos){
			fstream r1;
			r1.open("htmlfiles"+path.substr(0,31)+"shows.txt");
			if(r1.is_open()){
				unsigned int m;
				r1>>m;
				r1.close();
				r1.clear();
				fstream r2;
				r2.open("htmlfiles"+path.substr(0,31)+"shows.txt",ios::out);
				r2<<m+1;
				r2.close();
				r2.clear();
			}
		}
		if(workingcid=="no cid"&&path.find("users")!=string::npos){
			sendHtml(clientSocket,"htmlfiles/error/403.html",workingcid);
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/SENDSAYanonymous")!=string::npos){
			if(workingcid=="no cid"){
				closesocket(clientSocket);
				return;
			}
			sendsayanonymous(cache_,workingcid,clientSocket,0);
			closesocket(clientSocket);
			return;
		}else if(cache_.find("/m/SENDSAY")!=string::npos){
			if(workingcid=="no cid"){
				closesocket(clientSocket);
				return;
			}
			sendsay(cache_,workingcid,clientSocket,1);//����յ�������Ϣ 
			closesocket(clientSocket);
			return;
		}else if(cache_.find("/SENDSAY")!=string::npos){
			if(workingcid=="no cid"){
				closesocket(clientSocket);
				return;
			}
			sendsay(cache_,workingcid,clientSocket,0);//����յ�������Ϣ 
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/REGISTER")!=string::npos){
			_register(cache_,clientSocket);//����յ�������Ϣ 
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/LONGTIME")!=string::npos){
			if(workingcid=="no cid"){
				closesocket(clientSocket);
				return;
			}
			timetime(cache_,workingcid,clientSocket,0);//����յ�������Ϣ 
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/changebackground")!=string::npos){
			if(workingcid=="no cid"){
				closesocket(clientSocket);
				return;
			}
			
			choosebackground(cache_,workingcid);
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/email")!=string::npos){
			email(cache_,clientSocket);
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/changeavatar")!=string::npos){
			if(workingcid=="no cid"){
				closesocket(clientSocket);
				return;
			}
			
			chooseavatar(cache_,workingcid);
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/myavatar")!=string::npos){
			if(workingcid=="no cid"){
				sendthing("/favicon.ico",clientSocket);
				closesocket(clientSocket);
				return;
			}
			fstream r1;
			r1.open("htmlfiles/users/"+usernames[normalfind(cid,workingcid)]+"/avatar.txt");
			string url;
			r1>>url;
			r1.close();
			r1.clear();
			sendthing(url,clientSocket);
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/background")!=string::npos){
			if(workingcid=="no cid"){
				closesocket(clientSocket);
				return;
			}
			fstream r1;
			r1.open("htmlfiles/users/"+usernames[normalfind(cid,workingcid)]+"/background.txt");
			if(!r1.is_open()){
				sendthing("/background.png",clientSocket);
				closesocket(clientSocket);
				return;
			}
			string url;
			r1>>url;
			r1.close();
			r1.clear();
			sendthing(url,clientSocket);
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/myname")!=string::npos){
			if(workingcid=="no cid"){
				closesocket(clientSocket);
				return;
			}
			sendthing(usernames[normalfind(cid,workingcid)],clientSocket);
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/upload-audio")!=string::npos){
			if(workingcid=="no cid"){
				closesocket(clientSocket);
				return;
			}
			HandlePostRequest(buffer);
			sendthing("ed",clientSocket);
			closesocket(clientSocket);
		}
		if(cache_.find("/LOGIN")!=string::npos){
			login(cache_,clientSocket);//����յ�������Ϣ 
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/dailydata")!=string::npos){
			
			if(normalfind(cid,workingcid)==-1&&workingcid!="no cid"){
				sendthing("�������ǰ�",clientSocket);
			}else if(workingcid=="no cid")
				sendthing("�������ǰ�",clientSocket);
			else{
				int zishu=countChineseCharacters("htmlfiles/m/users/"+usernames[normalfind(cid,workingcid)]+"/sendsay.txt");
				fstream r1;
				r1.open("htmlfiles/users/"+usernames[normalfind(cid,workingcid)]+"/registertime.txt");
				int time_;
				r1>>time_;
				r1.close();
				r1.clear();
				sendthing("<p>��һ��д��"+to_string(zishu/3)+"���ֵ��ռ�</p>\n"+"<p>����������������ĵ�"+to_string((time(0)-time_)/86400+1)+"��</p>",clientSocket);
			}
			closesocket(clientSocket);
			return;
		}
		if(cache_.find("/rightcid")!=string::npos){
			if(normalfind(cid,workingcid)==-1&&workingcid!="no cid"){
				sendthing("no cid",clientSocket);
			}else if(workingcid=="no cid")
				sendthing("no cid",clientSocket);
			else
				sendthing("ok search",clientSocket);
			closesocket(clientSocket);
			return;
		}
		path = DecodeUrl(parseHttpRequest(request));
		cout << "����·��: " << path << endl;
		if(path=="/"){
			sendHtml(clientSocket,&"htmlFiles/index.html"[0],workingcid);
			closesocket(clientSocket);
			return;
		}
//		if(isSend304(path)){
//			string header = "HTTP/1.1 304 Not Modified\r\n\r\n";
//			send(clientSocket, header.c_str(), header.length(), 0);
//			return;
//		}
		sendHtml(clientSocket,&("htmlFiles"+path)[0],workingcid);
//		logs.unlock();
	} else if (iResult == 0)
		cout << "Connection closing..." << endl;
	else {
		printError("recv failed");
		closesocket(clientSocket);
		WSACleanup();
		return;
	}
	closesocket(clientSocket);
}
int main() {
	system("chcp 65001");
	WSADATA wsaData;
	int result;
	
	result = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (result != 0) {
		printError("WSAStartup failed");
		return 1;
	}
	
	struct addrinfo hints, *res = NULL;
	
	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;
	
	if (getaddrinfo(NULL, "81", &hints, &res) != 0) {
		printError("getaddrinfo failed");
		WSACleanup();
		return 1;
	}
	
	SOCKET listenSocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
	if (listenSocket == INVALID_SOCKET) {
		printError("socket failed");
		freeaddrinfo(res);
		WSACleanup();
		return 1;
	}
	
	if (bind(listenSocket, res->ai_addr, (int)res->ai_addrlen) == SOCKET_ERROR) {
		printError("bind failed");
		freeaddrinfo(res);
		closesocket(listenSocket);
		WSACleanup();
		return 1;
	}
	
	freeaddrinfo(res);
	if (listen(listenSocket, SOMAXCONN) == SOCKET_ERROR) {
		printError("listen failed");
		closesocket(listenSocket);
		WSACleanup();
		return 1;
	}
	fstream r1;
	r1.open("cid.txt");
	while(!r1.eof()){
		string m;
		getline(r1,m);
		cid.push_back(m);
	}
	loadUsers();
	loadsuperUsers();
	loademail();
	thread deldailydata(cleandailydata);
	deldailydata.detach();
	thread savecid_(savecid);
	savecid_.detach();
	thread shudong_(shudong);
	shudong_.detach();
	thread makehtml_(maketimehtml);
	makehtml_.detach();
	thread makemessagehtml_(makemessagehtml);
	makemessagehtml_.detach();
	while(1){
		cout << "���ڼ���81�˿�..." << endl;
		SOCKET clientSocket = accept(listenSocket, NULL, NULL);
		if (clientSocket == INVALID_SOCKET) {
			printError("accept failed");
			closesocket(listenSocket);
			WSACleanup();
			return 1;
		}
		thread recv_(handleClient,clientSocket);
		recv_.detach();
	}
	return 0;
}
