const nodemailer = require("nodemailer");
const fs = require("fs");  // 引入 fs 模块

// 配置126邮箱的SMTP服务
const transporter = nodemailer.createTransport({
    host: "smtp.126.com",  // 126 邮箱的 SMTP 服务器
    port: 465,  // 端口
    secure: true, // SSL加密
    auth: {
        user: "hjsxhst2022@126.com", // 你的126邮箱地址
        pass: "JFRYbWN6Nj85gdHT"  // 获取的授权码
    }
});

// 从文件读取 HTML 内容和收件人地址
fs.readFile("D:\\email.txt", "utf8", (err, htmlData) => {
    if (err) {
        console.log("读取 HTML 文件失败：", err);
        return;
    }

    fs.readFile("D:\\b.txt", "utf8", (err, recipientData) => {
        if (err) {
            console.log("读取收件人文件失败：", err);
            return;
        }

        // 邮件内容
        const mailOptions = {
            from: "hjsxhst2022@126.com",  // 发件人邮箱
            to: recipientData.trim(),  // 收件人邮箱（去除空格和换行）
            subject: "轻写 - 验证码",
            text: "轻写 - 验证码",  // 普通文本内容
            html: htmlData  // 从文件中读取的 HTML 内容
        };

        // 发送邮件
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.log("邮件发送失败：", error);
            } else {
                console.log("邮件发送成功！ID: " + info.messageId);
            }
        });
    });
});
