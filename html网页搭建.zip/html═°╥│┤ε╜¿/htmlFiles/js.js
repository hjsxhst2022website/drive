// Cookie 处理函数
function deleteSpecificCookie(cookieName) {
  var now = new Date();
  now.setUTCFullYear(1970);
  document.cookie = cookieName + "=; expires=" + now.toUTCString() + "; path=/;";
}

function checkCookieExists(cookieName) {
  var cookies = document.cookie.split(';');
  for(var i = 0; i < cookies.length; i++) {
    var cookie = cookies[i].trim();
    if (cookie.indexOf(cookieName + '=') === 0) {
      return true;
    }
  }
  return false;
}

function deleteCookie() {
  document.cookie = "cid=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
}


document.addEventListener('DOMContentLoaded', function () {
  var playPauseButton = document.getElementById('playPauseButton');
  var audioPlayer = document.getElementById('myAudio');
  
  // 延迟存储播放时间（防止频繁的 localStorage 写操作）
  let debounceTimeout = null;
  function debounceSaveState() {
    if (debounceTimeout) {
      clearTimeout(debounceTimeout);
    }
    debounceTimeout = setTimeout(() => {
      localStorage.setItem('currentTime', audioPlayer.currentTime);
    }, 100); // 每1秒保存一次播放时间，防止频繁写入
  }

  // 音频加载和恢复播放状态
  var isPlaying = localStorage.getItem('isPlaying');
  var currentTime = parseFloat(localStorage.getItem('currentTime'));

  // 如果状态是播放且时间有效，恢复播放
  if (isPlaying === 'true' && isValidTime(currentTime)) {
    console.log('Stored time:', currentTime);
    audioPlayer.currentTime = currentTime;
    audioPlayer.play().catch(function (error) {
      console.error("无法自动播放音频：", error);
    });
    playPauseButton.textContent = '点击暂停';
  } else {
    console.log('音频未播放或存储时间无效');
    playPauseButton.textContent = '点击播放';
  }

  // 检查时间值是否有效
  function isValidTime(time) {
    return typeof time === 'number' && !isNaN(time) && isFinite(time);
  }

  // 设置音频元素的播放时间
  function setAudioTime(audioElement, time) {
    if (isValidTime(time)) {
      audioElement.currentTime = time;
    } else {
      console.error('Invalid time value:', time);
    }
  }

  // 点击播放/暂停按钮的逻辑
  playPauseButton.addEventListener('click', function () {
    if (audioPlayer.paused) {
      audioPlayer.play().catch(function (error) {
        console.error("无法播放音频：", error);
        alert("需要用户互动才能播放音频。");
      });
      playPauseButton.textContent = '点击暂停';
      // 存储播放状态和当前播放时间
      localStorage.setItem('isPlaying', 'true');
      localStorage.setItem('currentTime', audioPlayer.currentTime);
    } else {
      audioPlayer.pause();
      playPauseButton.textContent = '点击播放';
      // 存储暂停状态
      localStorage.setItem('isPlaying', 'false');
      // 存储当前播放时间
      localStorage.setItem('currentTime', audioPlayer.currentTime);
    }
  });

  // 每次音频播放进度变化时，延迟存储播放时间
  audioPlayer.addEventListener('timeupdate', function () {
    if (!audioPlayer.paused) {
      debounceSaveState();
    }
  });
  // Live2D 动画异步加载优化
  function initLive2D() {
    var live2dWidget = L2Dwidget.init({
      "model": {
        "jsonPath": "https://unpkg.com/live2d-widget-model-hijiki@1.0.5/assets/hijiki.model.json",
        "scale": 1
      },
      "display": {
        "position": "left",
        "width": 100,
        "height": 200,
        "hOffset": 70,
        "vOffset": 0
      },
      "mobile": {
        "show": false,
        "scale": 0.8
      },
      "react": {
        "opacityDefault": 0.95,
        "opacityOnHover": 0.1
      }
    });
    window.onload = function () {
      $("#live2dcanvas").attr("style", "position: fixed; opacity: 0.93; left: 70px; bottom: 0px; z-index: 1; pointer-events: none;");
    }
  }

  // 使用异步加载模型的方式
  setTimeout(initLive2D, 1000); // 延迟 2 秒后加载 Live2D 动画

  // 控制页面中的 iframe 显示逻辑
  var iframes = document.querySelectorAll('iframe');
  iframes.forEach(function(iframe) {
    var src = iframe.src.toLowerCase();
    if (src.includes('bilibili.com')) {
      console.log('Valid iframe source for video playback.');
    } else {
      console.log('Invalid iframe source. Removing iframe...');
      iframe.parentNode.removeChild(iframe); // 如果不符合条件，则移除 iframe
    }
  });

  // Cookie 处理函数
  function deleteSpecificCookie(cookieName) {
    var now = new Date();
    now.setUTCFullYear(1970);
    document.cookie = cookieName + "=; expires=" + now.toUTCString() + "; path=/;";
  }

  function checkCookieExists(cookieName) {
    var cookies = document.cookie.split(';');
    for(var i = 0; i < cookies.length; i++) {
      var cookie = cookies[i].trim();
      if (cookie.indexOf(cookieName + '=') === 0) {
        return true;
      }
    }
    return false;
  }

  function deleteCookie() {
    document.cookie = "cid=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  }
  
});
