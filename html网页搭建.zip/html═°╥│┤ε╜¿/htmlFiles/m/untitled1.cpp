#include <iostream>
#include <windows.h>
#include <psapi.h>
#include <pdh.h>
#include<bits/stdc++.h>
#pragma comment(lib, "pdh.lib")
using namespace std;
// 获取系统内存状态信息
void GetSystemMemoryStatus() {
	MEMORYSTATUSEX memStatus;
	memStatus.dwLength = sizeof(memStatus);
	if (GlobalMemoryStatusEx(&memStatus)) {
		int allmem= memStatus.ullTotalPhys / (1024 * 1024) ;
		int canusemem= memStatus.ullAvailPhys / (1024 * 1024) ;
		cout << "总物理内存: " <<allmem<< " MB" << endl;
		cout << "可用物理内存: " <<canusemem<< " MB" << endl;
		double memoryUsage = 100.0 * (1.0 - (double)memStatus.ullAvailPhys / (double)memStatus.ullTotalPhys);
		cout << "物理内存使用百分比： " << memoryUsage << " %" << endl;

	} else {
		cerr << "Failed to get system memory status." << endl;
	}
}

// 获取CPU使用率
double GetCpuUsage() {
	PDH_HQUERY cpuQuery;
	PDH_HCOUNTER cpuTotal;
	
	PdhOpenQuery(NULL, NULL, &cpuQuery);
	PdhAddCounter(cpuQuery, "\\Processor(_Total)\\% Processor Time", NULL, &cpuTotal);
	PdhCollectQueryData(cpuQuery);
	Sleep(500);
	PdhCollectQueryData(cpuQuery);
	
	PDH_FMT_COUNTERVALUE counterVal;
	PdhGetFormattedCounterValue(cpuTotal, PDH_FMT_DOUBLE, NULL, &counterVal);
	PdhCloseQuery(cpuQuery);
	
	return counterVal.doubleValue;
}

// 获取网络速度
void GetNetworkSpeed() {
	PDH_STATUS status;
	PDH_HQUERY query;
	PDH_HCOUNTER counterRx;
	PDH_HCOUNTER counterTx;
	PDH_FMT_COUNTERVALUE rxValue;
	PDH_FMT_COUNTERVALUE txValue;
	
	status = PdhOpenQuery(NULL, NULL, &query);
	if (status != ERROR_SUCCESS) {
		cerr << "Error opening query for network speed: " << status << endl;
		return;
	}
	
	status = PdhAddCounter(query, "\\Network Interface(*)\\Bytes Received/sec", NULL, &counterRx);
	if (status != ERROR_SUCCESS) {
		cerr << "Error adding counter for network speed (Rx): " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	status = PdhAddCounter(query, "\\Network Interface(*)\\Bytes Sent/sec", NULL, &counterTx);
	if (status != ERROR_SUCCESS) {
		cerr << "Error adding counter for network speed (Tx): " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	status = PdhCollectQueryData(query);
	if (status != ERROR_SUCCESS) {
		cerr << "Error collecting query data for network speed: " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	Sleep(1000);
	status = PdhCollectQueryData(query);
	if (status != ERROR_SUCCESS) {
		cerr << "Error collecting query data for network speed: " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	status = PdhGetFormattedCounterValue(counterRx, PDH_FMT_LARGE, NULL, &rxValue);
	if (status != ERROR_SUCCESS) {
		cerr << "Error getting formatted counter value for network speed (Rx): " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	status = PdhGetFormattedCounterValue(counterTx, PDH_FMT_LARGE, NULL, &txValue);
	if (status != ERROR_SUCCESS) {
		cerr << "Error getting formatted counter value for network speed (Tx): " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	cout << "网络速度(接收): " <<setprecision(10)<< rxValue.largeValue*1.0 << " MB/s" << endl;
	cout << "网络速度(传输): " <<setprecision(10)<< txValue.largeValue*1.0<< " MB/s" << endl;
	
	PdhCloseQuery(query);
}

// 获取硬盘读写速度
void GetDiskSpeed() {
	PDH_STATUS status;
	PDH_HQUERY query;
	PDH_HCOUNTER counterRead;
	PDH_HCOUNTER counterWrite;
	PDH_FMT_COUNTERVALUE readValue;
	PDH_FMT_COUNTERVALUE writeValue;
	
	status = PdhOpenQuery(NULL, NULL, &query);
	if (status != ERROR_SUCCESS) {
		cerr << "Error opening query for disk speed: " << status << endl;
		return;
	}
	
	status = PdhAddCounter(query, "\\PhysicalDisk(_Total)\\Disk Read Bytes/sec", NULL, &counterRead);
	if (status != ERROR_SUCCESS) {
		cerr << "Error adding counter for disk speed (Read): " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	status = PdhAddCounter(query, "\\PhysicalDisk(_Total)\\Disk Write Bytes/sec", NULL, &counterWrite);
	if (status != ERROR_SUCCESS) {
		cerr << "Error adding counter for disk speed (Write): " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	status = PdhCollectQueryData(query);
	if (status != ERROR_SUCCESS) {
		cerr << "Error collecting query data for disk speed: " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	Sleep(500);
	status = PdhCollectQueryData(query);
	if (status != ERROR_SUCCESS) {
		cerr << "Error collecting query data for disk speed: " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	status = PdhGetFormattedCounterValue(counterRead, PDH_FMT_LARGE, NULL, &readValue);
	if (status != ERROR_SUCCESS) {
		cerr << "Error getting formatted counter value for disk speed (Read): " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	status = PdhGetFormattedCounterValue(counterWrite, PDH_FMT_LARGE, NULL, &writeValue);
	if (status != ERROR_SUCCESS) {
		cerr << "Error getting formatted counter value for disk speed (Write): " << status << endl;
		PdhCloseQuery(query);
		return;
	}
	
	cout << "磁盘速度（读取）： " <<setprecision(10)<< readValue.largeValue*1.0 / (1024 * 1024) << " MB/s" << endl;
	cout << "磁盘速度（写入）： " <<setprecision(10)<< writeValue.largeValue*1.0 / (1024 * 1024) << " MB/s" << endl;
	
	PdhCloseQuery(query);
}
int main() {
	while(1){
		freopen("test.css","w",stdout);
		GetSystemMemoryStatus();
		double cpuUsage = GetCpuUsage();
		cout << "CPU利用率 : " << cpuUsage << " %" << endl;
		GetNetworkSpeed();
		GetDiskSpeed();
		Sleep(1000);
	}
	return 0;
}

