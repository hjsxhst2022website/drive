//document.addEventListener('DOMContentLoaded', function() {
//	document.body.addEventListener('click', function(event) {
//		// 创建一个点击特效元素
//		const effect = document.createElement('div');
//		effect.className = 'click-effect';
//		effect.style.left = `${event.clientX}px`;
//		effect.style.top = `${event.clientY}px`;
//		document.body.appendChild(effect);
//		
//		// 立即触发动画，然后在动画结束后删除元素
//		setTimeout(() => {
//			effect.classList.add('fade-out');
//			
//			// 监听动画结束事件
//			const onTransitionEnd = () => {
//				// 在尝试移除之前，确保该元素还是其父元素的子元素
//				if (effect.parentNode === document.body) {
//					document.body.removeChild(effect);
//				}
//				// 清理：移除事件监听器
//				effect.removeEventListener('transitionend', onTransitionEnd);
//			};
//			
//			effect.addEventListener('transitionend', onTransitionEnd);
//		}, 0);
//	});
//});
