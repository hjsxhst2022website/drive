// Cookie 处理函数
function deleteSpecificCookie(cookieName) {
  var now = new Date();
  now.setUTCFullYear(1970);
  document.cookie = cookieName + "=; expires=" + now.toUTCString() + "; path=/;";
}

function checkCookieExists(cookieName) {
  var cookies = document.cookie.split(';');
  for(var i = 0; i < cookies.length; i++) {
    var cookie = cookies[i].trim();
    if (cookie.indexOf(cookieName + '=') === 0) {
      return true;
    }
  }
  return false;
}

function deleteCookie() {
  document.cookie = "cid=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
}

function deletemCookie() {
deleteCookie();
  document.cookie = "cid=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
}
document.addEventListener('DOMContentLoaded', function () {
  var playPauseButton = document.getElementById('playPauseButton');
  var audioPlayer = document.getElementById('myAudio');
  
  // 延迟存储播放时间（防止频繁的 localStorage 写操作）
  let debounceTimeout = null;
  function debounceSaveState() {
    if (debounceTimeout) {
      clearTimeout(debounceTimeout);
    }
    debounceTimeout = setTimeout(() => {
      localStorage.setItem('currentTime', audioPlayer.currentTime);
    }, 100); // 每1秒保存一次播放时间，防止频繁写入
  }

  // 音频加载和恢复播放状态
  var isPlaying = localStorage.getItem('isPlaying');
  var currentTime = parseFloat(localStorage.getItem('currentTime'));

  // 如果状态是播放且时间有效，恢复播放
  if (isPlaying === 'true' && isValidTime(currentTime)) {
    console.log('Stored time:', currentTime);
    audioPlayer.currentTime = currentTime;
    audioPlayer.play().catch(function (error) {
      console.error("无法自动播放音频：", error);
    });
    playPauseButton.textContent = '点击暂停';
  } else {
    console.log('音频未播放或存储时间无效');
    playPauseButton.textContent = '点击播放';
  }

  // 检查时间值是否有效
  function isValidTime(time) {
    return typeof time === 'number' && !isNaN(time) && isFinite(time);
  }

  // 设置音频元素的播放时间
  function setAudioTime(audioElement, time) {
    if (isValidTime(time)) {
      audioElement.currentTime = time;
    } else {
      console.error('Invalid time value:', time);
    }
  }

  // 点击播放/暂停按钮的逻辑
  playPauseButton.addEventListener('click', function () {
    if (audioPlayer.paused) {
      audioPlayer.play().catch(function (error) {
        console.error("无法播放音频：", error);
        alert("需要用户互动才能播放音频。");
      });
      playPauseButton.textContent = '点击暂停';
      // 存储播放状态和当前播放时间
      localStorage.setItem('isPlaying', 'true');
      localStorage.setItem('currentTime', audioPlayer.currentTime);
    } else {
      audioPlayer.pause();
      playPauseButton.textContent = '点击播放';
      // 存储暂停状态
      localStorage.setItem('isPlaying', 'false');
      // 存储当前播放时间
      localStorage.setItem('currentTime', audioPlayer.currentTime);
    }
  });

  // 每次音频播放进度变化时，延迟存储播放时间
  audioPlayer.addEventListener('timeupdate', function () {
    if (!audioPlayer.paused) {
      debounceSaveState();
    }
  });
  // Live2D 动画异步加载优化
  function initLive2D() {
    var live2dWidget = L2Dwidget.init({
      "model": {
        "jsonPath": "https://unpkg.com/live2d-widget-model-hijiki@1.0.5/assets/hijiki.model.json",
        "scale": 1
      },
      "display": {
        "position": "left",
        "width": 100,
        "height": 200,
        "hOffset": 70,
        "vOffset": 0
      },
      "mobile": {
        "show": false,
        "scale": 0.8
      },
      "react": {
        "opacityDefault": 0.95,
        "opacityOnHover": 0.1
      }
    });
    window.onload = function () {
      $("#live2dcanvas").attr("style", "position: fixed; opacity: 0.93; left: 70px; bottom: 0px; z-index: 1; pointer-events: none;");
    }
  }

  // 使用异步加载模型的方式
  setTimeout(initLive2D, 1000); // 延迟 2 秒后加载 Live2D 动画

  // 控制页面中的 iframe 显示逻辑
  var iframes = document.querySelectorAll('iframe');
  iframes.forEach(function(iframe) {
    var src = iframe.src.toLowerCase();
    if (src.includes('bilibili.com')) {
      console.log('Valid iframe source for video playback.');
    } else {
      console.log('Invalid iframe source. Removing iframe...');
      iframe.parentNode.removeChild(iframe); // 如果不符合条件，则移除 iframe
    }
  });

  // Cookie 处理函数
  function deleteSpecificCookie(cookieName) {
    var now = new Date();
    now.setUTCFullYear(1970);
    document.cookie = cookieName + "=; expires=" + now.toUTCString() + "; path=/;";
  }

  function checkCookieExists(cookieName) {
    var cookies = document.cookie.split(';');
    for(var i = 0; i < cookies.length; i++) {
      var cookie = cookies[i].trim();
      if (cookie.indexOf(cookieName + '=') === 0) {
        return true;
      }
    }
    return false;
  }

  function deleteCookie() {
    document.cookie = "cid=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  }
  
  // 鼠标点击特效
  $("body").click(function(e) {
    var messages = [
"晨光熹微，新的一天带着希望悄然而至。",
"夕阳的余晖，温柔地洒在归家的路上。",
"一杯热茶，足以驱散冬日的寒意。",
"家的味道，是熟悉而温馨的香气。",
"雨后初晴，空气中弥漫着泥土的清新与温暖。",
"书页间跳跃的文字，是心灵的慰藉与滋养。",
"窗外的绿意，让人心生宁静与喜悦。",
"一盏夜灯，照亮了孤独者的心房。",
"老友相聚，时光仿佛倒流，温暖如初。",
"孩子的笑声，是世界上最纯净的乐章。",
"冬日里的暖阳，让人忘却寒冷，沉醉于温暖之中。",
"家人的叮咛，虽简单却饱含深情与关怀。",
"一抹夕阳，将天边染成温柔的橘红色。",
"静谧的夜晚，星光点点，温暖着夜行者的心灵。",
"一杯热巧克力，是冬日里的小确幸。",
"家的温馨，不在于物质的堆砌，而在于心灵的相依。",
"春日的暖阳，融化了冰雪，也温暖了人心。",
"老友的信件，字里行间透露着岁月的温情。",
"一杯清茶，一本好书，足以度过一个悠闲的午后。",
"家的灯火，是远方游子心中最温暖的灯塔。",
"秋日的落叶，虽飘零却带着季节的诗意与温暖。",
"一杯热牛奶，让疲惫的心灵得到片刻的安宁。",
"家人的笑容，是世界上最温馨的风景。",
"雨后的彩虹，如同生活中的小惊喜，温暖人心。",
"一本旧相册，翻开着往昔的记忆，温暖如初。",
"冬日的壁炉旁，家人围坐，温馨而惬意。",
"家的味道，是母亲烹饪的菜肴，香气四溢。",
"春日的花朵，绽放出生命的活力与温暖。",
"一杯咖啡的香气，足以唤醒沉睡的感官。",
"家人的拥抱，虽短暂却充满力量与温暖。",
"秋日的黄昏，天边的云彩如同温柔的画卷。",
"一杯淡酒，与朋友共饮，话尽人生百态，温暖如初。",
"家的温馨，在于每一次归来的期待与满足。",
"夏日的微风，轻轻拂过，带来一丝丝凉爽与温馨。",
"一本新书的开启，如同探索未知世界的旅程，充满期待。",
"家人的关怀，如同春雨般润物无声，滋养心田。",
"冬日的雪景，纯洁而宁静，让人心生向往与温暖。",
"一杯果汁的甘甜，如同生活中的小确幸，简单而美好。",
"家的灯火阑珊处，总有一个人在默默等待，温暖如初。",
"春日的细雨，如同大自然的低语，温柔而细腻。",
"一杯茶的时光，足以让人忘却尘世的烦恼与喧嚣。",
"家人的陪伴，是最长情的告白，温暖而坚定。",
"秋日的果实，满载着季节的馈赠，让人心生感激与温暖。",
"一杯热可可的香气，足以驱散冬日的严寒与孤寂。",
"家的温馨，如同港湾中的灯塔，指引着归家的方向。",
"夏日的蝉鸣，如同夏日的序曲，热闹而温馨。",
"一本好书的陪伴，如同一位智者，引领着心灵的成长。",
"家人的笑容，如同阳光般明媚，温暖着每一个人的心房。",
"冬日的早晨，阳光透过窗帘，洒下斑驳的光影，温馨而宁静。",
"一杯茶的余温，如同生活的余韵，让人回味无穷。",
"家的味道，是父亲烹饪的佳肴，藏着深深的爱意与温暖。",
"春日的鸟鸣，如同大自然的乐章，悦耳而温馨。",
"一杯水的清澈，如同心灵的纯净，让人心生宁静与喜悦。",
"家人的牵挂，如同风筝的线，无论飞多远都能感受到那份温暖。",
"秋日的丰收，如同生活的馈赠，让人心生满足与温暖。",
"一杯茶的香气，如同岁月的沉淀，让人心生敬畏与温暖。",
"家的温馨，如同心灵的港湾，无论风雨多大都能找到依靠。",
"夏日的傍晚，与家人漫步在夕阳下，温馨而惬意。",
"一本诗集的翻阅，如同心灵的旅行，让人心生向往与温暖。",
"家人的眼神，如同夜空中最亮的星，温暖而坚定。",
"冬日的午后，阳光洒满房间，温暖而宁静，如同岁月的馈赠。",
"一杯茶的滋味，如同生活的酸甜苦辣，让人心生感慨与温暖。",
"家的温馨，如同冬日里的暖阳，温暖而持久，照亮前行的路。"
      // ... 更多温暖的句子
    ];
    var randomMessage = messages[Math.floor(Math.random() * messages.length)];
    var $i = $("<span></span>").text(randomMessage);
    var x = e.pageX, y = e.pageY;
    $i.css({
      "z-index": 9999,
      "top": y - 2,
      "left": x,
      "position": "absolute",
      "font-weight": "bold",
      "color": "rgb("+~~(255*Math.random())+","+~~(255*Math.random())+","+~~(255*Math.random())+")"
    });
    $("body").append($i);
    $i.animate({
      "top": y - 180,
      "opacity": 0
    }, 1500, function() {
      $i.remove();
    });
  });
});
